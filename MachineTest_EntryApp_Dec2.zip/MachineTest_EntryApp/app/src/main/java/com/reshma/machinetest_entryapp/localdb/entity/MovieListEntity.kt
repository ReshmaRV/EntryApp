package com.reshma.machinetest_entryapp.localdb.entity

import androidx.room.*


@Entity(tableName = "movie_table")
data class MovieListEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "movieId")
    var movieId: Int? = null,

    @Embedded
    var dates: Dates,

    @ColumnInfo(name = "page")
    var page: Int? = null,

    @Embedded
    var results: List<Movie>,

    @ColumnInfo(name = "total_pages")
    var total_pages: Int? = null,

    @ColumnInfo(name = "total_results")
    var total_results: Int? = null
)

