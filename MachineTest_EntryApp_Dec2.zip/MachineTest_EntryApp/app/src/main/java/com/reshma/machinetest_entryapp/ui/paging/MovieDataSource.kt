package com.reshma.machinetest_entryapp.ui.paging

import androidx.paging.PagingSource
import androidx.paging.PagingState
import com.reshma.machinetest_entryapp.localdb.entity.Movie
import com.reshma.machinetest_entryapp.remote.Api
import com.reshma.machinetest_entryapp.remote.repo.Repository
import com.reshma.machinetest_entryapp.remote.response.MovieResult

import com.reshma.machinetest_entryapp.utils.network.ApiEmptyResponse
import com.reshma.machinetest_entryapp.utils.network.ApiErrorResponse
import com.reshma.machinetest_entryapp.utils.network.ApiSuccessResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import timber.log.Timber

import javax.inject.Inject
import kotlin.collections.ArrayList

//DataSource for pager
class MovieDataSource @Inject constructor(
    private val api: Api, private val repository: Repository, private val API_KEY: String
) : PagingSource<Int, MovieResult>() {

    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, MovieResult> {
        return try {
            val nextPageNumber = params.key ?: 0
            var movieResponse = ArrayList<MovieResult>()
            CoroutineScope(Dispatchers.IO).launch {
                repository.fetchMovieList(API_KEY, nextPageNumber.toString())
                    ?.collect { response ->
                        when (response) {
                            is ApiSuccessResponse -> {
                                val list =
                                    response.data?.results?.mapIndexed { index, movieResult ->
                                        Movie(
                                            movieResult.adult,
                                            movieResult.backdrop_path,
                                            movieResult.genre_ids,
                                            movieResult.id,
                                            movieResult.original_language,
                                            movieResult.original_title,
                                            movieResult.overview,
                                            movieResult.popularity,
                                            movieResult.poster_path,
                                            movieResult.release_date,
                                            movieResult.title,
                                            movieResult.video,
                                            movieResult.vote_average,
                                            movieResult.vote_count
                                        )
                                    }

                                if (list != null) {
                                    //Insert to Local DB ROOM
                                    insertDataToLocalDB(list)
                                }
                                movieResponse = response.data?.results!! as ArrayList<MovieResult>
                            }
                            is ApiErrorResponse -> { Timber.d("API response Error")
                            }
                            is ApiEmptyResponse -> {Timber.d("API response Empty")
                            }

                        }

                    }
            }

            LoadResult.Page(
                data = movieResponse,
                prevKey = if (nextPageNumber > 0) nextPageNumber - 1 else null,
                nextKey = nextPageNumber + 1
            )
        } catch (e: Exception) {
            LoadResult.Error(e)
        }
    }

    override fun getRefreshKey(state: PagingState<Int, MovieResult>): Int? = null

    private suspend fun insertDataToLocalDB(movieList: List<Movie>) {
        //insert to repo
        repository.insertData(movieList)
    }

}
