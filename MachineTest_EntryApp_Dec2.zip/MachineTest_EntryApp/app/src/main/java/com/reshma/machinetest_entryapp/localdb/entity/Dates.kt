package com.reshma.machinetest_entryapp.localdb.entity


import androidx.room.ColumnInfo

data class Dates(
    @ColumnInfo(name = "maximum")
    var maximum: String?=null,

    @ColumnInfo(name = "minimum")
    var minimum: String?=null
)
