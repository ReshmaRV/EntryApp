package com.reshma.machinetest_entryapp.localdb

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.reshma.machinetest_entryapp.localdb.entity.Movie


import kotlinx.coroutines.flow.Flow

@Dao
interface MachineTestEntryAppDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertData(data: List<Movie>)

    @Query("SELECT * FROM movie_table")
    fun getMovieList(): Flow<List<Movie>>
}
