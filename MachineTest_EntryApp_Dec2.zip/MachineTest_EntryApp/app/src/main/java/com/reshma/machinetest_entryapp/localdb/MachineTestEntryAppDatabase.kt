package com.reshma.machinetest_entryapp.localdb

import androidx.room.Database
import androidx.room.RoomDatabase
import com.reshma.machinetest_entryapp.localdb.entity.MovieListEntity

@Database(
    entities = [MovieListEntity::class],
    version = 1,
    exportSchema = false
)

abstract class MachineTestEntryAppDatabase : RoomDatabase() {
    abstract fun machineTestDao(): MachineTestEntryAppDao
}
