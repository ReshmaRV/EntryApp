package com.reshma.machinetest_entryapp.ui.splash

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.paging.map
import com.reshma.machinetest_entryapp.MainActivity
import com.reshma.machinetest_entryapp.utils.Utils.startNewActivity

import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import timber.log.Timber

@AndroidEntryPoint
class LaunchActivity : AppCompatActivity() {
    private val viewModel: LaunchViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setUpMovieList()

    }

    //Navigate to Movie List if movie list fetch successfully
    private fun setUpMovieList() {
        lifecycleScope.launch {
            viewModel.fetchMovieList.collectLatest {
                it.map { movieResult ->
                    if (movieResult != null) {
                        isNavigate(true)
                    }
                }

            }
        }
    }

    //Navigate to Movie List
    private fun isNavigate(navigate: Boolean) {
        when (navigate) {
            true -> navigateToHome()
            false -> Timber.d("Do nothing")
        }
    }

    //Navigate to MainActivity
    private fun navigateToHome() {
        startNewActivity(MainActivity::class.java)
        finish()
    }
}